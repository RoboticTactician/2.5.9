// Vyas Gupta

public class Book {
  private int rating;
  private String title;
  private String author;

  /** Constructor **/
  public Book(String title, String author) {
    this.title = title;
    this.author = author;
  }

  /** Accessor methods **/
  public String getTitle() {
    return title;
  }

  public String getAuthor() {
    return author;
  }

  public int getRating() {
    return rating;
  }

  public String toString() {
    String info = "\"" + title + "\", written by " + author;
    if (rating != 0) {
      info += ", rating is " + rating;
    }
    return info;
  }

  /** Equals method **/
  public boolean equals(Book otherBook) {
    return this.title.equals(otherBook.title) && this.author.equals(otherBook.author);
  }

  /** Mutator methods **/
  public void setAuthor(String author) {
    this.author = author;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  /** Adjust rating method **/
  public void adjustRating(int ratingChange) {
    // Ensure the new rating is within the valid range [0, 10]
    if (isValidRatingChange(ratingChange)) {
      rating += ratingChange;
    }
  }

  private boolean isValidRatingChange(int ratingChange) {
    return rating + ratingChange >= 0 && rating + ratingChange <= 10;
  }
}
