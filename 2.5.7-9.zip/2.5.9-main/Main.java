// Vyas Gupta

public class Main {
  public static void main(String[] args) {
    // Step 1
    System.out.println(MediaLib.getOwner() + "'s Library");

    // Step 8
    MediaLib.changeOwner("Vyas Gupta");
    System.out.println(MediaLib.getOwner() + "'s Library");

    MediaLib books = new MediaLib();
    MediaLib movies = new MediaLib();

    Book book1 = new Book("Cats", "Author1");
    books.addBook(book1);

    Book book2 = new Book("Cats", "Author1");
    movies.addBook(book2);

    // Step 17
    System.out.println(books.getNumEntries());

    books.addBook(new Book("Dogs", "Author2"));
    books.addBook(new Book("Dogs", "Author2"));

    System.out.println(books.getNumEntries()); // Step 22

    // Additional testing
    System.out.println("Books Library:");
    System.out.println(books); // This will print the book information

    System.out.println("Movies Library:");
    System.out.println(movies); // This will print an empty string as there is no book in the movies library
  }
}
