// Vyas Gupta

public class MediaLib {
  private Book book;
  private static String owner = "PLTW";
  private static int numEntries = 0;

  public void addBook(Book b) {
    if (book != null) {
      System.out.println("Error: Book already exists in the library.");
      return;
    }
    numEntries++;
    book = b;
  }

  public String toString() {
    if (book == null) {
      return "No books in the library.";
    }
    return "Book: " + book + "\n";
  }

  public static String getOwner() {
    return owner;
  }

  public static void changeOwner(String newOwner) {
    owner = newOwner;
  }

  public int getNumEntries() {
    System.out.println("Owner: " + owner);
    return numEntries;
  }
}
